  $( document ).on("page:load ready", function() {
    $(function() {
        $( '#datepicker' ).datepicker({
          dateFormat: "M-dd-yy"
        });
      });
  });
